const dataUser = [
  {
    id: "1",
    name: "Muhammad Mardiansyah",
    email: "mardiansyahm002@gmail.com",
    picture: "https://example.com/pictures/john_doe.jpg",
  },
  {
    id: "2",
    name: "Mark Zuckerberg",
    email: "mardiansyahm12@gmail.com",
    picture: "https://example.com/pictures/jane_smith.jpg",
  },
  {
    id: "3",
    name: "Eren",
    email: "eren@gmail.com",
    picture: "https://example.com/pictures/jane_smith.jpg",
  },
  {
    id: "4",
    name: "Tanjiro",
    email: "tanjiro@gmail.com",
    picture: "https://example.com/pictures/jane_smith.jpg",
  },
];

module.exports = dataUser;
