const conversations = [
  {
    id: "1",
    user_id_one: "1",
    user_id_two: "2",
  },
  {
    id: "2",
    user_id_one: "1",
    user_id_two: "3",
  },
];

module.exports = conversations;
