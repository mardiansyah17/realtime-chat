const messages = [
  {
    id: "1",
    content: "halo mark",
    sender_id: "1",
    conversation_id: "1",
  },
  {
    id: "2",
    content: "last",
    sender_id: "2",
    conversation_id: "2",
  },
];
module.exports = messages;
